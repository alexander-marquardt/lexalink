# Initialize Django
from djangoappengine import main

from google.appengine.ext.appstats.ui import app as application, main


if __name__ == '__main__':
    main()
